# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: settings-free.spec.js >> Free plugin — Settings save/persist (Pro inactive) >> Guest Notice toggle saves and persists
- Location: tests/settings-free.spec.js:92:3

# Error details

```
Error: expect(locator).toHaveJSProperty(expected) failed

Locator:  locator('tr').filter({ has: locator('th').filter({ hasText: 'Guest Notice' }) }).locator('input[type="checkbox"]')
Expected: false
Received: true
Timeout:  5000ms

Call log:
  - Expect "toHaveJSProperty" with timeout 5000ms
  - waiting for locator('tr').filter({ has: locator('th').filter({ hasText: 'Guest Notice' }) }).locator('input[type="checkbox"]')
    13 × locator resolved to <input checked type="checkbox" id="classic-cb-cci2nx0" class="!pointbay-hidden"/>
       - unexpected value "true"

```

```yaml
- navigation "Main menu":
  - link "Skip to main content":
    - /url: "#wpbody-content"
  - link "Skip to toolbar":
    - /url: "#wp-toolbar"
  - list:
    - listitem:
      - link "Dashboard":
        - /url: index.php
      - list:
        - listitem:
          - link "Home":
            - /url: index.php
        - listitem:
          - link "Updates":
            - /url: update-core.php
    - listitem:
      - link "Posts":
        - /url: edit.php
      - list:
        - listitem:
          - link "All Posts":
            - /url: edit.php
        - listitem:
          - link "Add Post":
            - /url: post-new.php
        - listitem:
          - link "Categories":
            - /url: edit-tags.php?taxonomy=category
        - listitem:
          - link "Tags":
            - /url: edit-tags.php?taxonomy=post_tag
    - listitem:
      - link "Media":
        - /url: upload.php
      - list:
        - listitem:
          - link "Library":
            - /url: upload.php
        - listitem:
          - link "Add Media File":
            - /url: media-new.php
    - listitem:
      - link "Pages":
        - /url: edit.php?post_type=page
      - list:
        - listitem:
          - link "All Pages":
            - /url: edit.php?post_type=page
        - listitem:
          - link "Add Page":
            - /url: post-new.php?post_type=page
    - listitem:
      - link "Comments":
        - /url: edit-comments.php
    - listitem:
      - link "WooCommerce":
        - /url: admin.php?page=wc-admin
      - list:
        - listitem:
          - link "Home 6":
            - /url: admin.php?page=wc-admin
        - listitem:
          - link "Orders":
            - /url: admin.php?page=wc-orders
        - listitem:
          - link "Points History":
            - /url: admin.php?page=pointbay-ledger
        - listitem:
          - link "Loyalty":
            - /url: admin.php?page=wc-settings&tab=pointbay
        - listitem:
          - link "Customers":
            - /url: admin.php?page=wc-admin&path=/customers
        - listitem:
          - link "Coupons":
            - /url: admin.php?page=coupons-moved
        - listitem:
          - link "Reports":
            - /url: admin.php?page=wc-reports
        - listitem:
          - link "Settings":
            - /url: admin.php?page=wc-settings
        - listitem:
          - link "Status":
            - /url: admin.php?page=wc-status
        - listitem:
          - link "Extensions":
            - /url: admin.php?page=wc-admin&path=/extensions
    - listitem:
      - link "Products":
        - /url: edit.php?post_type=product
      - list:
        - listitem:
          - link "All Products":
            - /url: edit.php?post_type=product
        - listitem:
          - link "Add new product":
            - /url: post-new.php?post_type=product
        - listitem:
          - link "Brands":
            - /url: edit-tags.php?taxonomy=product_brand&post_type=product
        - listitem:
          - link "Categories":
            - /url: edit-tags.php?taxonomy=product_cat&post_type=product
        - listitem:
          - link "Tags":
            - /url: edit-tags.php?taxonomy=product_tag&post_type=product
        - listitem:
          - link "Attributes":
            - /url: edit.php?post_type=product&page=product_attributes
        - listitem:
          - link "Reviews":
            - /url: edit.php?post_type=product&page=product-reviews
    - listitem:
      - link "Payments":
        - /url: admin.php?page=wc-settings&tab=checkout&from=PAYMENTS_MENU_ITEM
    - listitem:
      - link "Analytics":
        - /url: admin.php?page=wc-admin&path=/analytics/overview
      - list:
        - listitem:
          - link "Overview":
            - /url: admin.php?page=wc-admin&path=/analytics/overview
        - listitem:
          - link "Products":
            - /url: admin.php?page=wc-admin&path=/analytics/products
        - listitem:
          - link "Revenue":
            - /url: admin.php?page=wc-admin&path=/analytics/revenue
        - listitem:
          - link "Orders":
            - /url: admin.php?page=wc-admin&path=/analytics/orders
        - listitem:
          - link "Variations":
            - /url: admin.php?page=wc-admin&path=/analytics/variations
        - listitem:
          - link "Categories":
            - /url: admin.php?page=wc-admin&path=/analytics/categories
        - listitem:
          - link "Coupons":
            - /url: admin.php?page=wc-admin&path=/analytics/coupons
        - listitem:
          - link "Taxes":
            - /url: admin.php?page=wc-admin&path=/analytics/taxes
        - listitem:
          - link "Downloads":
            - /url: admin.php?page=wc-admin&path=/analytics/downloads
        - listitem:
          - link "Stock":
            - /url: admin.php?page=wc-admin&path=/analytics/stock
        - listitem:
          - link "Settings":
            - /url: admin.php?page=wc-admin&path=/analytics/settings
    - listitem:
      - link "Marketing":
        - /url: admin.php?page=wc-admin&path=/marketing
      - list:
        - listitem:
          - link "Overview":
            - /url: admin.php?page=wc-admin&path=/marketing
        - listitem:
          - link "Coupons":
            - /url: edit.php?post_type=shop_coupon
    - listitem:
      - link "Appearance":
        - /url: themes.php
      - list:
        - listitem:
          - link "Themes":
            - /url: themes.php
        - listitem:
          - link "Design":
            - /url: site-editor.php
        - listitem:
          - link "Customize":
            - /url: customize.php?return=%2Fwp-admin%2Fadmin.php%3Fpage%3Dwc-settings%26tab%3Dpointbay
        - listitem:
          - link "Widgets":
            - /url: widgets.php
        - listitem:
          - link "Fonts":
            - /url: font-library.php
        - listitem:
          - link "Menus":
            - /url: nav-menus.php
        - listitem:
          - link "Header":
            - /url: customize.php?return=%2Fwp-admin%2Fadmin.php%3Fpage%3Dwc-settings%26tab%3Dpointbay&autofocus%5Bcontrol%5D=header_image
        - listitem:
          - link "Background":
            - /url: customize.php?return=%2Fwp-admin%2Fadmin.php%3Fpage%3Dwc-settings%26tab%3Dpointbay&autofocus%5Bcontrol%5D=background_image
        - listitem:
          - link "Storefront":
            - /url: themes.php?page=storefront-welcome
        - listitem
        - listitem
        - listitem:
          - link "Theme File Editor":
            - /url: theme-editor.php
    - listitem:
      - link "Plugins":
        - /url: plugins.php
      - list:
        - listitem:
          - link "Installed Plugins":
            - /url: plugins.php
        - listitem:
          - link "Add Plugin":
            - /url: plugin-install.php
        - listitem:
          - link "Plugin File Editor":
            - /url: plugin-editor.php
    - listitem:
      - link "Users":
        - /url: users.php
      - list:
        - listitem:
          - link "All Users":
            - /url: users.php
        - listitem:
          - link "Add User":
            - /url: user-new.php
        - listitem:
          - link "Profile":
            - /url: profile.php
    - listitem:
      - link "Tools":
        - /url: tools.php
      - list:
        - listitem:
          - link "Available Tools":
            - /url: tools.php
        - listitem:
          - link "Import":
            - /url: import.php
        - listitem:
          - link "Export":
            - /url: export.php
        - listitem:
          - link "Site Health":
            - /url: site-health.php
        - listitem:
          - link "Export Personal Data":
            - /url: export-personal-data.php
        - listitem:
          - link "Erase Personal Data":
            - /url: erase-personal-data.php
        - listitem:
          - link "Scheduled Actions":
            - /url: tools.php?page=action-scheduler
    - listitem:
      - link "Settings":
        - /url: options-general.php
      - list:
        - listitem:
          - link "General":
            - /url: options-general.php
        - listitem:
          - link "Connectors":
            - /url: options-connectors.php
        - listitem:
          - link "Writing":
            - /url: options-writing.php
        - listitem:
          - link "Reading":
            - /url: options-reading.php
        - listitem:
          - link "Discussion":
            - /url: options-discussion.php
        - listitem:
          - link "Media":
            - /url: options-media.php
        - listitem:
          - link "Permalinks":
            - /url: options-permalink.php
        - listitem:
          - link "Privacy":
            - /url: options-privacy.php
    - listitem:
      - button "Collapse Main menu" [expanded]: Collapse Menu
- navigation "Toolbar":
  - menu:
    - group:
      - menuitem "About WordPress"
    - group:
      - menuitem "Test Site"
    - group:
      - menuitem "Store coming soon"
    - group:
      - menuitem "Ctrl+K Open command palette"
    - group:
      - menuitem "0 Comments in moderation"
    - group:
      - menuitem "New"
    - group:
      - menuitem "Network Restricted"
  - menu:
    - group:
      - menuitem "Howdy, admin"
- heading "Settings" [level=1]
- main:
  - navigation:
    - link "General":
      - /url: http://localhost:32769/wp-admin/admin.php?page=wc-settings&tab=general
    - link "Products":
      - /url: http://localhost:32769/wp-admin/admin.php?page=wc-settings&tab=products
    - link "Shipping":
      - /url: http://localhost:32769/wp-admin/admin.php?page=wc-settings&tab=shipping
    - link "Payments":
      - /url: http://localhost:32769/wp-admin/admin.php?page=wc-settings&tab=checkout
    - link "Accounts & Privacy":
      - /url: http://localhost:32769/wp-admin/admin.php?page=wc-settings&tab=account
    - link "Emails":
      - /url: http://localhost:32769/wp-admin/admin.php?page=wc-settings&tab=email
    - link "Integration":
      - /url: http://localhost:32769/wp-admin/admin.php?page=wc-settings&tab=integration
    - link "Site visibility":
      - /url: http://localhost:32769/wp-admin/admin.php?page=wc-settings&tab=site-visibility
    - link "Point of Sale":
      - /url: http://localhost:32769/wp-admin/admin.php?page=wc-settings&tab=point-of-sale
    - link "Loyalty Points":
      - /url: http://localhost:32769/wp-admin/admin.php?page=wc-settings&tab=pointbay
    - link "Advanced":
      - /url: http://localhost:32769/wp-admin/admin.php?page=wc-settings&tab=advanced
  - heading "Loyalty Points" [level=1]
  - heading "Earning Points" [level=2]
  - paragraph: Configure how customers earn loyalty points.
  - table:
    - rowgroup:
      - row "Points Per Dollar 1 How many points the customer earns for every $1 spent.":
        - rowheader "Points Per Dollar"
        - cell "1 How many points the customer earns for every $1 spent.":
          - spinbutton: "1"
          - paragraph: How many points the customer earns for every $1 spent.
      - row "Points for Registration 0 Give new users this many points when they register.":
        - rowheader "Points for Registration"
        - cell "0 Give new users this many points when they register.":
          - spinbutton: "0"
          - paragraph: Give new users this many points when they register.
      - row "Points for Product Review 0 Reward points for an approved product review.":
        - rowheader "Points for Product Review"
        - cell "0 Reward points for an approved product review.":
          - spinbutton: "0"
          - paragraph: Reward points for an approved product review.
      - row "Order Status Trigger The WooCommerce order status that triggers points crediting.":
        - rowheader "Order Status Trigger"
        - cell "The WooCommerce order status that triggers points crediting.":
          - combobox: Completed
          - paragraph: The WooCommerce order status that triggers points crediting.
  - heading "Redemption Rules" [level=2]
  - paragraph: Configure how points are converted to discounts.
  - table:
    - rowgroup:
      - row "Point Value ($) 0.01 The monetary value of a single point.":
        - rowheader "Point Value ($)"
        - cell "0.01 The monetary value of a single point.":
          - spinbutton: "0.01"
          - paragraph: The monetary value of a single point.
      - row "Redemption Mode How the discount is applied to the cart.":
        - rowheader "Redemption Mode"
        - cell "How the discount is applied to the cart.":
          - combobox: Cart Fee (WC_Fee)
          - paragraph: How the discount is applied to the cart.
      - row "Minimum Points to Redeem 100 The minimum amount of points needed before the redemption form is shown.":
        - rowheader "Minimum Points to Redeem"
        - cell "100 The minimum amount of points needed before the redemption form is shown.":
          - spinbutton: "100"
          - paragraph: The minimum amount of points needed before the redemption form is shown.
  - heading "Referrals" [level=2]
  - paragraph: Reward customers for referring their friends.
  - table:
    - rowgroup:
      - row "New Customer Bonus Points 100 Points awarded to the new customer themselves after their first purchase via a referral link.":
        - rowheader "New Customer Bonus Points"
        - cell "100 Points awarded to the new customer themselves after their first purchase via a referral link.":
          - spinbutton [disabled]: "100"
          - paragraph: Points awarded to the new customer themselves after their first purchase via a referral link.
      - row "Enable Referrals Turn on the referral program Gives every customer a shareable link that credits them when a friend they refer completes a first order.":
        - rowheader "Enable Referrals"
        - cell "Turn on the referral program Gives every customer a shareable link that credits them when a friend they refer completes a first order.":
          - img
          - text: Turn on the referral program
          - paragraph: Gives every customer a shareable link that credits them when a friend they refer completes a first order.
      - row "Referral Bonus Points 1000 Points awarded to the referrer after the new customer's first purchase.":
        - rowheader "Referral Bonus Points"
        - cell "1000 Points awarded to the referrer after the new customer's first purchase.":
          - spinbutton [disabled]: "1000"
          - paragraph: Points awarded to the referrer after the new customer's first purchase.
  - heading "Display & System" [level=2]
  - paragraph: Additional display and maintenance options.
  - table:
    - rowgroup:
      - row "Guest Notice Show login/register prompt on checkout":
        - rowheader "Guest Notice"
        - cell "Show login/register prompt on checkout":
          - img
          - text: Show login/register prompt on checkout
      - row "Delete Data on Uninstall Purge all ledger data upon deletion":
        - rowheader "Delete Data on Uninstall"
        - cell "Purge all ledger data upon deletion":
          - img
          - text: Purge all ledger data upon deletion
      - row "Debug Logging Write diagnostic messages to the WordPress debug log":
        - rowheader "Debug Logging"
        - cell "Write diagnostic messages to the WordPress debug log":
          - img
          - text: Write diagnostic messages to the WordPress debug log
  - heading "VIP Tiers PRO" [level=2]
  - paragraph: Group customers into tiers with earning multipliers based on annual points.
  - table:
    - rowgroup:
      - row "Enable VIP Tiers Enable automatic tier recalculation Tiers Configuration Bronze 0 1 Silver 500 1.2 Gold 2000 1.5":
        - rowheader "Enable VIP Tiers"
        - cell "Enable automatic tier recalculation Tiers Configuration Bronze 0 1 Silver 500 1.2 Gold 2000 1.5":
          - img
          - text: Enable automatic tier recalculation
          - heading "Tiers Configuration" [level=4]
          - textbox [disabled]: Bronze
          - spinbutton [disabled]: "0"
          - spinbutton [disabled]: "1"
          - textbox [disabled]: Silver
          - spinbutton [disabled]: "500"
          - spinbutton [disabled]: "1.2"
          - textbox [disabled]: Gold
          - spinbutton [disabled]: "2000"
          - spinbutton [disabled]: "1.5"
  - heading "License Settings PRO" [level=2]
  - paragraph: Activate your license key to enable automatic updates.
  - table:
    - rowgroup:
      - row "License Status INACTIVE":
        - rowheader "License Status"
        - cell "INACTIVE"
      - row "License Key Activate Enter your WPAnchorBay license key. You can find it in your purchase receipt.":
        - rowheader "License Key"
        - cell "Activate Enter your WPAnchorBay license key. You can find it in your purchase receipt.":
          - textbox "WPAB-XXXXX-XXXXX-XXXXX" [disabled]
          - button "Activate" [disabled]
          - paragraph: Enter your WPAnchorBay license key. You can find it in your purchase receipt.
  - paragraph:
    - button "Save changes" [disabled]
- contentinfo:
  - paragraph:
    - text: If you like
    - strong: WooCommerce
    - text: please leave us a
    - link "five star":
      - /url: https://wordpress.org/support/plugin/woocommerce/reviews?rate=5#new-post
      - text: ★★★★★
    - text: rating. A huge thanks in advance!
  - paragraph: Version 11.0.0
```

# Test source

```ts
  1   | const { test, expect } = require('@playwright/test');
  2   | const { loginAndOpenSettings, stepShot, resetStepCounter, saveSettings } = require('./helpers');
  3   | 
  4   | /**
  5   |  * Covers every free-plugin setting field on WooCommerce → Settings → Loyalty
  6   |  * Points: change it, save, reload, confirm the new value persisted. Runs
  7   |  * against the "free-only" QIT environment (PointBayPro not installed).
  8   |  */
  9   | 
  10  | /** Numeric fields: [row label substring, new value to set, expected persisted value]. */
  11  | const NUMBER_FIELDS = [
  12  | 	{ label: 'Points Per Dollar', value: '5' },
  13  | 	{ label: 'Points for Registration', value: '250' },
  14  | 	{ label: 'Points for Product Review', value: '75' },
  15  | 	{ label: 'Point Value ($)', value: '0.05' },
  16  | 	{ label: 'Minimum Points to Redeem', value: '200' },
  17  | 	{ label: 'Referral Bonus Points', value: '1500' },
  18  | ];
  19  | 
  20  | /** Select fields: [row label substring, option value to choose]. */
  21  | const SELECT_FIELDS = [
  22  | 	{ label: 'Order Status Trigger', value: 'processing' },
  23  | 	{ label: 'Redemption Mode', value: 'coupon' },
  24  | ];
  25  | 
  26  | /** Checkbox fields: [row label substring]. */
  27  | const CHECKBOX_FIELDS = ['Enable Referrals', 'Guest Notice', 'Delete Data on Uninstall', 'Debug Logging'];
  28  | 
  29  | test.describe('Free plugin — Settings save/persist (Pro inactive)', () => {
  30  | 	test.beforeEach(async ({ page }, testInfo) => {
  31  | 		resetStepCounter();
  32  | 		await loginAndOpenSettings(page);
  33  | 		await stepShot(page, testInfo, 'settings-loaded');
  34  | 	});
  35  | 
  36  | 	for (const field of NUMBER_FIELDS) {
  37  | 		test(`${field.label} saves and persists`, async ({ page }, testInfo) => {
  38  | 			const row = page.locator('tr', { has: page.locator('th', { hasText: field.label }) });
  39  | 			const input = row.locator('input').first();
  40  | 
  41  | 			// Referral Bonus Points is disabled until Enable Referrals is on.
  42  | 			if (field.label === 'Referral Bonus Points') {
  43  | 				const enableReferralsRow = page.locator('tr', { has: page.locator('th', { hasText: 'Enable Referrals' }) });
  44  | 				const checkbox = enableReferralsRow.locator('input[type="checkbox"]');
  45  | 				if (!(await checkbox.isChecked())) {
  46  | 					await enableReferralsRow.locator('label').first().click();
  47  | 				}
  48  | 			}
  49  | 
  50  | 			await expect(input).toBeVisible();
  51  | 			await stepShot(page, testInfo, `${field.label}-before`);
  52  | 
  53  | 			await input.fill('');
  54  | 			await input.fill(field.value);
  55  | 			await stepShot(page, testInfo, `${field.label}-changed`);
  56  | 
  57  | 			await saveSettings(page);
  58  | 			await stepShot(page, testInfo, `${field.label}-saved`);
  59  | 
  60  | 			await page.reload();
  61  | 			await page.waitForSelector('.pointbay-p-page-default');
  62  | 			const reloadedRow = page.locator('tr', { has: page.locator('th', { hasText: field.label }) });
  63  | 			const reloadedInput = reloadedRow.locator('input').first();
  64  | 			await expect(reloadedInput).toHaveValue(field.value);
  65  | 			await stepShot(page, testInfo, `${field.label}-reloaded-confirmed`);
  66  | 		});
  67  | 	}
  68  | 
  69  | 	for (const field of SELECT_FIELDS) {
  70  | 		test(`${field.label} saves and persists`, async ({ page }, testInfo) => {
  71  | 			const row = page.locator('tr', { has: page.locator('th', { hasText: field.label }) });
  72  | 			const select = row.locator('select');
  73  | 
  74  | 			await expect(select).toBeVisible();
  75  | 			await stepShot(page, testInfo, `${field.label}-before`);
  76  | 
  77  | 			await select.selectOption(field.value);
  78  | 			await stepShot(page, testInfo, `${field.label}-changed`);
  79  | 
  80  | 			await saveSettings(page);
  81  | 			await stepShot(page, testInfo, `${field.label}-saved`);
  82  | 
  83  | 			await page.reload();
  84  | 			await page.waitForSelector('.pointbay-p-page-default');
  85  | 			const reloadedRow = page.locator('tr', { has: page.locator('th', { hasText: field.label }) });
  86  | 			await expect(reloadedRow.locator('select')).toHaveValue(field.value);
  87  | 			await stepShot(page, testInfo, `${field.label}-reloaded-confirmed`);
  88  | 		});
  89  | 	}
  90  | 
  91  | 	for (const label of CHECKBOX_FIELDS) {
  92  | 		test(`${label} toggle saves and persists`, async ({ page }, testInfo) => {
  93  | 			const row = page.locator('tr', { has: page.locator('th', { hasText: label }) });
  94  | 			const checkbox = row.locator('input[type="checkbox"]');
  95  | 
  96  | 			await stepShot(page, testInfo, `${label}-before`);
  97  | 			const wasChecked = await checkbox.isChecked();
  98  | 
  99  | 			await row.locator('label').first().click();
  100 | 			await stepShot(page, testInfo, `${label}-toggled`);
> 101 | 			await expect(checkbox).toHaveJSProperty('checked', !wasChecked);
      |                           ^ Error: expect(locator).toHaveJSProperty(expected) failed
  102 | 
  103 | 			await saveSettings(page);
  104 | 			await stepShot(page, testInfo, `${label}-saved`);
  105 | 
  106 | 			await page.reload();
  107 | 			await page.waitForSelector('.pointbay-p-page-default');
  108 | 			const reloadedRow = page.locator('tr', { has: page.locator('th', { hasText: label }) });
  109 | 			await expect(reloadedRow.locator('input[type="checkbox"]')).toHaveJSProperty('checked', !wasChecked);
  110 | 			await stepShot(page, testInfo, `${label}-reloaded-confirmed`);
  111 | 
  112 | 			// Restore original state so this test is repeatable and doesn't
  113 | 			// leak a changed toggle into the next test in the file.
  114 | 			await reloadedRow.locator('label').first().click();
  115 | 			await saveSettings(page);
  116 | 		});
  117 | 	}
  118 | });
  119 | 
```