# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: settings-free.spec.js >> Free plugin — Settings save/persist (Pro inactive) >> Points for Registration saves and persists
- Location: tests/settings-free.spec.js:37:3

# Error details

```
TypeError: saveSettings is not a function
```

# Page snapshot

```yaml
- generic [ref=f2e2]:
  - navigation "Main menu":
    - link "Skip to main content" [ref=f2e3] [cursor=pointer]:
      - /url: "#wpbody-content"
    - link "Skip to toolbar" [ref=f2e4] [cursor=pointer]:
      - /url: "#wp-toolbar"
    - list [ref=f2e7]:
      - listitem [ref=f2e8]:
        - link "Dashboard" [ref=f2e9] [cursor=pointer]:
          - /url: index.php
          - generic [ref=f2e10]: 
        - list [ref=f2e12]:
          - listitem [ref=f2e13]:
            - link "Home" [ref=f2e14] [cursor=pointer]:
              - /url: index.php
          - listitem [ref=f2e15]:
            - link "Updates" [ref=f2e16] [cursor=pointer]:
              - /url: update-core.php
      - listitem [ref=f2e17]
      - listitem [ref=f2e19]:
        - link "Posts" [ref=f2e20] [cursor=pointer]:
          - /url: edit.php
          - generic [ref=f2e21]: 
        - list [ref=f2e23]:
          - listitem [ref=f2e24]:
            - link "All Posts" [ref=f2e25] [cursor=pointer]:
              - /url: edit.php
          - listitem [ref=f2e26]:
            - link "Add Post" [ref=f2e27] [cursor=pointer]:
              - /url: post-new.php
          - listitem [ref=f2e28]:
            - link "Categories" [ref=f2e29] [cursor=pointer]:
              - /url: edit-tags.php?taxonomy=category
          - listitem [ref=f2e30]:
            - link "Tags" [ref=f2e31] [cursor=pointer]:
              - /url: edit-tags.php?taxonomy=post_tag
      - listitem [ref=f2e32]:
        - link "Media" [ref=f2e33] [cursor=pointer]:
          - /url: upload.php
          - generic [ref=f2e34]: 
        - list [ref=f2e36]:
          - listitem [ref=f2e37]:
            - link "Library" [ref=f2e38] [cursor=pointer]:
              - /url: upload.php
          - listitem [ref=f2e39]:
            - link "Add Media File" [ref=f2e40] [cursor=pointer]:
              - /url: media-new.php
      - listitem [ref=f2e41]:
        - link "Pages" [ref=f2e42] [cursor=pointer]:
          - /url: edit.php?post_type=page
          - generic [ref=f2e43]: 
        - list [ref=f2e45]:
          - listitem [ref=f2e46]:
            - link "All Pages" [ref=f2e47] [cursor=pointer]:
              - /url: edit.php?post_type=page
          - listitem [ref=f2e48]:
            - link "Add Page" [ref=f2e49] [cursor=pointer]:
              - /url: post-new.php?post_type=page
      - listitem [ref=f2e50]:
        - link "Comments" [ref=f2e51] [cursor=pointer]:
          - /url: edit-comments.php
          - generic [ref=f2e52]: 
      - listitem [ref=f2e54]
      - listitem [ref=f2e56]:
        - link "WooCommerce" [ref=f2e57] [cursor=pointer]:
          - /url: admin.php?page=wc-admin
        - list [ref=f2e60]:
          - listitem [ref=f2e61]:
            - link "Home 6" [ref=f2e62] [cursor=pointer]:
              - /url: admin.php?page=wc-admin
              - text: Home
              - generic [ref=f2e63]: "6"
          - listitem [ref=f2e64]:
            - link "Orders" [ref=f2e65] [cursor=pointer]:
              - /url: admin.php?page=wc-orders
          - listitem [ref=f2e66]:
            - link "Points History" [ref=f2e67] [cursor=pointer]:
              - /url: admin.php?page=pointbay-ledger
          - listitem [ref=f2e68]:
            - link "Loyalty" [ref=f2e69] [cursor=pointer]:
              - /url: admin.php?page=wc-settings&tab=pointbay
          - listitem [ref=f2e70]:
            - link "Customers" [ref=f2e71] [cursor=pointer]:
              - /url: admin.php?page=wc-admin&path=/customers
          - listitem [ref=f2e72]:
            - link "Coupons" [ref=f2e73] [cursor=pointer]:
              - /url: admin.php?page=coupons-moved
          - listitem [ref=f2e74]:
            - link "Reports" [ref=f2e75] [cursor=pointer]:
              - /url: admin.php?page=wc-reports
          - listitem [ref=f2e76]:
            - link "Settings" [ref=f2e77] [cursor=pointer]:
              - /url: admin.php?page=wc-settings
          - listitem [ref=f2e78]:
            - link "Status" [ref=f2e79] [cursor=pointer]:
              - /url: admin.php?page=wc-status
          - listitem [ref=f2e80]:
            - link "Extensions" [ref=f2e81] [cursor=pointer]:
              - /url: admin.php?page=wc-admin&path=/extensions
      - listitem [ref=f2e82]:
        - link "Products" [ref=f2e83] [cursor=pointer]:
          - /url: edit.php?post_type=product
          - generic [ref=f2e84]: 
        - list [ref=f2e86]:
          - listitem [ref=f2e87]:
            - link "All Products" [ref=f2e88] [cursor=pointer]:
              - /url: edit.php?post_type=product
          - listitem [ref=f2e89]:
            - link "Add new product" [ref=f2e90] [cursor=pointer]:
              - /url: post-new.php?post_type=product
          - listitem [ref=f2e91]:
            - link "Brands" [ref=f2e92] [cursor=pointer]:
              - /url: edit-tags.php?taxonomy=product_brand&post_type=product
          - listitem [ref=f2e93]:
            - link "Categories" [ref=f2e94] [cursor=pointer]:
              - /url: edit-tags.php?taxonomy=product_cat&post_type=product
          - listitem [ref=f2e95]:
            - link "Tags" [ref=f2e96] [cursor=pointer]:
              - /url: edit-tags.php?taxonomy=product_tag&post_type=product
          - listitem [ref=f2e97]:
            - link "Attributes" [ref=f2e98] [cursor=pointer]:
              - /url: edit.php?post_type=product&page=product_attributes
          - listitem [ref=f2e99]:
            - link "Reviews" [ref=f2e100] [cursor=pointer]:
              - /url: edit.php?post_type=product&page=product-reviews
      - listitem [ref=f2e101]:
        - link "Payments" [ref=f2e102] [cursor=pointer]:
          - /url: admin.php?page=wc-settings&tab=checkout&from=PAYMENTS_MENU_ITEM
      - listitem [ref=f2e105]:
        - link "Analytics" [ref=f2e106] [cursor=pointer]:
          - /url: admin.php?page=wc-admin&path=/analytics/overview
          - generic [ref=f2e107]: 
        - list [ref=f2e109]:
          - listitem [ref=f2e110]:
            - link "Overview" [ref=f2e111] [cursor=pointer]:
              - /url: admin.php?page=wc-admin&path=/analytics/overview
          - listitem [ref=f2e112]:
            - link "Products" [ref=f2e113] [cursor=pointer]:
              - /url: admin.php?page=wc-admin&path=/analytics/products
          - listitem [ref=f2e114]:
            - link "Revenue" [ref=f2e115] [cursor=pointer]:
              - /url: admin.php?page=wc-admin&path=/analytics/revenue
          - listitem [ref=f2e116]:
            - link "Orders" [ref=f2e117] [cursor=pointer]:
              - /url: admin.php?page=wc-admin&path=/analytics/orders
          - listitem [ref=f2e118]:
            - link "Variations" [ref=f2e119] [cursor=pointer]:
              - /url: admin.php?page=wc-admin&path=/analytics/variations
          - listitem [ref=f2e120]:
            - link "Categories" [ref=f2e121] [cursor=pointer]:
              - /url: admin.php?page=wc-admin&path=/analytics/categories
          - listitem [ref=f2e122]:
            - link "Coupons" [ref=f2e123] [cursor=pointer]:
              - /url: admin.php?page=wc-admin&path=/analytics/coupons
          - listitem [ref=f2e124]:
            - link "Taxes" [ref=f2e125] [cursor=pointer]:
              - /url: admin.php?page=wc-admin&path=/analytics/taxes
          - listitem [ref=f2e126]:
            - link "Downloads" [ref=f2e127] [cursor=pointer]:
              - /url: admin.php?page=wc-admin&path=/analytics/downloads
          - listitem [ref=f2e128]:
            - link "Stock" [ref=f2e129] [cursor=pointer]:
              - /url: admin.php?page=wc-admin&path=/analytics/stock
          - listitem [ref=f2e130]:
            - link "Settings" [ref=f2e131] [cursor=pointer]:
              - /url: admin.php?page=wc-admin&path=/analytics/settings
      - listitem [ref=f2e132]:
        - link "Marketing" [ref=f2e133] [cursor=pointer]:
          - /url: admin.php?page=wc-admin&path=/marketing
          - generic [ref=f2e134]: 
        - list [ref=f2e136]:
          - listitem [ref=f2e137]:
            - link "Overview" [ref=f2e138] [cursor=pointer]:
              - /url: admin.php?page=wc-admin&path=/marketing
          - listitem [ref=f2e139]:
            - link "Coupons" [ref=f2e140] [cursor=pointer]:
              - /url: edit.php?post_type=shop_coupon
      - listitem [ref=f2e141]
      - listitem [ref=f2e143]:
        - link "Appearance" [ref=f2e144] [cursor=pointer]:
          - /url: themes.php
          - generic [ref=f2e145]: 
        - list [ref=f2e147]:
          - listitem [ref=f2e148]:
            - link "Themes" [ref=f2e149] [cursor=pointer]:
              - /url: themes.php
          - listitem [ref=f2e150]:
            - link "Design" [ref=f2e151] [cursor=pointer]:
              - /url: site-editor.php
          - listitem [ref=f2e152]:
            - link "Customize" [ref=f2e153] [cursor=pointer]:
              - /url: customize.php?return=%2Fwp-admin%2Fadmin.php%3Fpage%3Dwc-settings%26tab%3Dpointbay
          - listitem [ref=f2e154]:
            - link "Widgets" [ref=f2e155] [cursor=pointer]:
              - /url: widgets.php
          - listitem [ref=f2e156]:
            - link "Fonts" [ref=f2e157] [cursor=pointer]:
              - /url: font-library.php
          - listitem [ref=f2e158]:
            - link "Menus" [ref=f2e159] [cursor=pointer]:
              - /url: nav-menus.php
          - listitem [ref=f2e160]:
            - link "Header" [ref=f2e161] [cursor=pointer]:
              - /url: customize.php?return=%2Fwp-admin%2Fadmin.php%3Fpage%3Dwc-settings%26tab%3Dpointbay&autofocus%5Bcontrol%5D=header_image
          - listitem [ref=f2e162]:
            - link "Background" [ref=f2e163] [cursor=pointer]:
              - /url: customize.php?return=%2Fwp-admin%2Fadmin.php%3Fpage%3Dwc-settings%26tab%3Dpointbay&autofocus%5Bcontrol%5D=background_image
          - listitem [ref=f2e164]:
            - link "Storefront" [ref=f2e165] [cursor=pointer]:
              - /url: themes.php?page=storefront-welcome
          - listitem
          - listitem
          - listitem [ref=f2e166]:
            - link "Theme File Editor" [ref=f2e167] [cursor=pointer]:
              - /url: theme-editor.php
      - listitem [ref=f2e168]:
        - link "Plugins" [ref=f2e169] [cursor=pointer]:
          - /url: plugins.php
          - generic [ref=f2e170]: 
        - list [ref=f2e172]:
          - listitem [ref=f2e173]:
            - link "Installed Plugins" [ref=f2e174] [cursor=pointer]:
              - /url: plugins.php
          - listitem [ref=f2e175]:
            - link "Add Plugin" [ref=f2e176] [cursor=pointer]:
              - /url: plugin-install.php
          - listitem [ref=f2e177]:
            - link "Plugin File Editor" [ref=f2e178] [cursor=pointer]:
              - /url: plugin-editor.php
      - listitem [ref=f2e179]:
        - link "Users" [ref=f2e180] [cursor=pointer]:
          - /url: users.php
          - generic [ref=f2e181]: 
        - list [ref=f2e183]:
          - listitem [ref=f2e184]:
            - link "All Users" [ref=f2e185] [cursor=pointer]:
              - /url: users.php
          - listitem [ref=f2e186]:
            - link "Add User" [ref=f2e187] [cursor=pointer]:
              - /url: user-new.php
          - listitem [ref=f2e188]:
            - link "Profile" [ref=f2e189] [cursor=pointer]:
              - /url: profile.php
      - listitem [ref=f2e190]:
        - link "Tools" [ref=f2e191] [cursor=pointer]:
          - /url: tools.php
          - generic [ref=f2e192]: 
        - list [ref=f2e194]:
          - listitem [ref=f2e195]:
            - link "Available Tools" [ref=f2e196] [cursor=pointer]:
              - /url: tools.php
          - listitem [ref=f2e197]:
            - link "Import" [ref=f2e198] [cursor=pointer]:
              - /url: import.php
          - listitem [ref=f2e199]:
            - link "Export" [ref=f2e200] [cursor=pointer]:
              - /url: export.php
          - listitem [ref=f2e201]:
            - link "Site Health" [ref=f2e202] [cursor=pointer]:
              - /url: site-health.php
          - listitem [ref=f2e203]:
            - link "Export Personal Data" [ref=f2e204] [cursor=pointer]:
              - /url: export-personal-data.php
          - listitem [ref=f2e205]:
            - link "Erase Personal Data" [ref=f2e206] [cursor=pointer]:
              - /url: erase-personal-data.php
          - listitem [ref=f2e207]:
            - link "Scheduled Actions" [ref=f2e208] [cursor=pointer]:
              - /url: tools.php?page=action-scheduler
      - listitem [ref=f2e209]:
        - link "Settings" [ref=f2e210] [cursor=pointer]:
          - /url: options-general.php
          - generic [ref=f2e211]: 
        - list [ref=f2e213]:
          - listitem [ref=f2e214]:
            - link "General" [ref=f2e215] [cursor=pointer]:
              - /url: options-general.php
          - listitem [ref=f2e216]:
            - link "Connectors" [ref=f2e217] [cursor=pointer]:
              - /url: options-connectors.php
          - listitem [ref=f2e218]:
            - link "Writing" [ref=f2e219] [cursor=pointer]:
              - /url: options-writing.php
          - listitem [ref=f2e220]:
            - link "Reading" [ref=f2e221] [cursor=pointer]:
              - /url: options-reading.php
          - listitem [ref=f2e222]:
            - link "Discussion" [ref=f2e223] [cursor=pointer]:
              - /url: options-discussion.php
          - listitem [ref=f2e224]:
            - link "Media" [ref=f2e225] [cursor=pointer]:
              - /url: options-media.php
          - listitem [ref=f2e226]:
            - link "Permalinks" [ref=f2e227] [cursor=pointer]:
              - /url: options-permalink.php
          - listitem [ref=f2e228]:
            - link "Privacy" [ref=f2e229] [cursor=pointer]:
              - /url: options-privacy.php
      - listitem [ref=f2e230]:
        - button "Collapse Main menu" [expanded] [ref=f2e231] [cursor=pointer]:
          - generic [ref=f2e233]: Collapse Menu
  - generic [ref=f2e234]:
    - generic [ref=f2e235]:
      - navigation "Toolbar":
        - menu:
          - group [ref=f2e236]:
            - menuitem "About WordPress" [ref=f2e237] [cursor=pointer]
          - group [ref=f2e240]:
            - menuitem "Test Site" [ref=f2e241] [cursor=pointer]
          - group [ref=f2e242]:
            - menuitem "Store coming soon" [ref=f2e243] [cursor=pointer]
          - group [ref=f2e244]:
            - menuitem "Ctrl+K Open command palette" [ref=f2e245] [cursor=pointer]:
              - generic [ref=f2e247]:
                - text: Ctrl+K
                - generic [ref=f2e248]: Open command palette
          - group [ref=f2e249]:
            - menuitem "0 Comments in moderation" [ref=f2e250] [cursor=pointer]:
              - generic [ref=f2e252]: "0"
          - group [ref=f2e254]:
            - menuitem "New" [ref=f2e255] [cursor=pointer]
          - group [ref=f2e258]:
            - menuitem "Network Restricted" [ref=f2e259] [cursor=pointer]:
              - generic [ref=f2e260]: 
              - text: Network Restricted
        - menu [ref=f2e261]:
          - group [ref=f2e262]:
            - menuitem "Howdy, admin" [ref=f2e263] [cursor=pointer]
    - heading "Settings" [level=1] [ref=f2e266]
    - main [ref=f2e268]:
      - generic [ref=f2e271]:
        - navigation [ref=f2e272]:
          - link "General" [ref=f2e273] [cursor=pointer]:
            - /url: http://localhost:32769/wp-admin/admin.php?page=wc-settings&tab=general
          - link "Products" [ref=f2e274] [cursor=pointer]:
            - /url: http://localhost:32769/wp-admin/admin.php?page=wc-settings&tab=products
          - link "Shipping" [ref=f2e275] [cursor=pointer]:
            - /url: http://localhost:32769/wp-admin/admin.php?page=wc-settings&tab=shipping
          - link "Payments" [ref=f2e276] [cursor=pointer]:
            - /url: http://localhost:32769/wp-admin/admin.php?page=wc-settings&tab=checkout
          - link "Accounts & Privacy" [ref=f2e277] [cursor=pointer]:
            - /url: http://localhost:32769/wp-admin/admin.php?page=wc-settings&tab=account
          - link "Emails" [ref=f2e278] [cursor=pointer]:
            - /url: http://localhost:32769/wp-admin/admin.php?page=wc-settings&tab=email
          - link "Integration" [ref=f2e279] [cursor=pointer]:
            - /url: http://localhost:32769/wp-admin/admin.php?page=wc-settings&tab=integration
          - link "Site visibility" [ref=f2e280] [cursor=pointer]:
            - /url: http://localhost:32769/wp-admin/admin.php?page=wc-settings&tab=site-visibility
          - link "Point of Sale" [ref=f2e281] [cursor=pointer]:
            - /url: http://localhost:32769/wp-admin/admin.php?page=wc-settings&tab=point-of-sale
          - link "Loyalty Points" [ref=f2e282] [cursor=pointer]:
            - /url: http://localhost:32769/wp-admin/admin.php?page=wc-settings&tab=pointbay
          - link "Advanced" [ref=f2e283] [cursor=pointer]:
            - /url: http://localhost:32769/wp-admin/admin.php?page=wc-settings&tab=advanced
        - heading "Loyalty Points" [level=1] [ref=f2e284]
        - generic [ref=f2e287]:
          - generic [ref=f2e288]:
            - heading "Earning Points" [level=2] [ref=f2e289]
            - paragraph [ref=f2e290]: Configure how customers earn loyalty points.
            - table [ref=f2e291]:
              - rowgroup [ref=f2e292]:
                - row [ref=f2e293]:
                  - rowheader "Points Per Dollar" [ref=f2e294]
                  - cell [ref=f2e297]:
                    - spinbutton [ref=f2e298]: "1"
                    - paragraph [ref=f2e299]: How many points the customer earns for every $1 spent.
                - row [ref=f2e300]:
                  - rowheader "Points for Registration" [ref=f2e301]
                  - cell [ref=f2e304]:
                    - spinbutton [active] [ref=f2e305]: "250"
                    - paragraph [ref=f2e306]: Give new users this many points when they register.
                - row [ref=f2e307]:
                  - rowheader "Points for Product Review" [ref=f2e308]
                  - cell [ref=f2e311]:
                    - spinbutton [ref=f2e312]: "0"
                    - paragraph [ref=f2e313]: Reward points for an approved product review.
                - row [ref=f2e314]:
                  - rowheader "Order Status Trigger" [ref=f2e315]
                  - cell [ref=f2e318]:
                    - generic [ref=f2e319]:
                      - combobox [ref=f2e321] [cursor=pointer]:
                        - generic [ref=f2e322]: Completed
                      - paragraph [ref=f2e323]: The WooCommerce order status that triggers points crediting.
          - generic [ref=f2e324]:
            - heading "Redemption Rules" [level=2] [ref=f2e325]
            - paragraph [ref=f2e326]: Configure how points are converted to discounts.
            - table [ref=f2e327]:
              - rowgroup [ref=f2e328]:
                - row [ref=f2e329]:
                  - rowheader "Point Value ($)" [ref=f2e330]
                  - cell [ref=f2e333]:
                    - spinbutton [ref=f2e334]: "0.01"
                    - paragraph [ref=f2e335]: The monetary value of a single point.
                - row [ref=f2e336]:
                  - rowheader "Redemption Mode" [ref=f2e337]
                  - cell [ref=f2e340]:
                    - generic [ref=f2e341]:
                      - combobox [ref=f2e343] [cursor=pointer]:
                        - generic [ref=f2e344]: Cart Fee (WC_Fee)
                      - paragraph [ref=f2e345]: How the discount is applied to the cart.
                - row [ref=f2e346]:
                  - rowheader "Minimum Points to Redeem" [ref=f2e347]
                  - cell [ref=f2e350]:
                    - spinbutton [ref=f2e351]: "100"
                    - paragraph [ref=f2e352]: The minimum amount of points needed before the redemption form is shown.
          - generic [ref=f2e353]:
            - heading "Referrals" [level=2] [ref=f2e354]
            - paragraph [ref=f2e355]: Reward customers for referring their friends.
            - table [ref=f2e356]:
              - rowgroup [ref=f2e357]:
                - row [ref=f2e358]:
                  - rowheader "New Customer Bonus Points" [ref=f2e359]
                  - cell [ref=f2e362]:
                    - generic [ref=f2e363]:
                      - generic:
                        - spinbutton [disabled]: "100"
                        - paragraph: Points awarded to the new customer themselves after their first purchase via a referral link.
                - row [ref=f2e367]:
                  - rowheader "Enable Referrals" [ref=f2e368]
                  - cell "Turn on the referral program Gives every customer a shareable link that credits them when a friend they refer completes a first order." [ref=f2e371]:
                    - generic [ref=f2e372]:
                      - generic [ref=f2e373] [cursor=pointer]: Turn on the referral program
                      - paragraph [ref=f2e376]: Gives every customer a shareable link that credits them when a friend they refer completes a first order.
                - row [ref=f2e377]:
                  - rowheader "Referral Bonus Points" [ref=f2e378]
                  - cell [ref=f2e381]:
                    - spinbutton [disabled] [ref=f2e382]: "1000"
                    - paragraph [ref=f2e383]: Points awarded to the referrer after the new customer's first purchase.
          - generic [ref=f2e384]:
            - heading "Display & System" [level=2] [ref=f2e385]
            - paragraph [ref=f2e386]: Additional display and maintenance options.
            - table [ref=f2e387]:
              - rowgroup [ref=f2e388]:
                - row [ref=f2e389]:
                  - rowheader "Guest Notice" [ref=f2e390]
                  - cell "Show login/register prompt on checkout" [ref=f2e393]
                - row [ref=f2e400]:
                  - rowheader "Delete Data on Uninstall" [ref=f2e401]
                  - cell "Purge all ledger data upon deletion" [ref=f2e404]
                - row [ref=f2e409]:
                  - rowheader "Debug Logging" [ref=f2e410]
                  - cell "Write diagnostic messages to the WordPress debug log" [ref=f2e413]
          - generic [ref=f2e418]:
            - heading "VIP Tiers PRO" [level=2] [ref=f2e419]:
              - text: VIP Tiers
              - generic [ref=f2e420]: PRO
            - paragraph [ref=f2e421]: Group customers into tiers with earning multipliers based on annual points.
            - table [ref=f2e422]:
              - rowgroup [ref=f2e423]:
                - row [ref=f2e424]:
                  - rowheader "Enable VIP Tiers" [ref=f2e425]
                  - cell [ref=f2e428]:
                    - generic [ref=f2e429]:
                      - generic:
                        - generic: Enable automatic tier recalculation
                        - generic:
                          - heading "Tiers Configuration" [level=4]
                          - generic:
                            - generic:
                              - textbox [disabled]: Bronze
                              - spinbutton [disabled]: "0"
                              - spinbutton [disabled]: "1"
                            - generic:
                              - textbox [disabled]: Silver
                              - spinbutton [disabled]: "500"
                              - spinbutton [disabled]: "1.2"
                            - generic:
                              - textbox [disabled]: Gold
                              - spinbutton [disabled]: "2000"
                              - spinbutton [disabled]: "1.5"
          - generic [ref=f2e433]:
            - heading "License Settings PRO" [level=2] [ref=f2e434]:
              - text: License Settings
              - generic [ref=f2e435]: PRO
            - paragraph [ref=f2e436]: Activate your license key to enable automatic updates.
            - table [ref=f2e437]:
              - rowgroup [ref=f2e438]:
                - row [ref=f2e439]:
                  - rowheader "License Status" [ref=f2e440]
                  - cell "INACTIVE" [ref=f2e443]
                - row [ref=f2e448]:
                  - rowheader "License Key" [ref=f2e449]
                  - cell [ref=f2e452]:
                    - generic [ref=f2e453]:
                      - generic:
                        - generic:
                          - generic:
                            - textbox "WPAB-XXXXX-XXXXX-XXXXX" [disabled]
                            - button "Activate" [disabled]
                          - paragraph: Enter your WPAnchorBay license key. You can find it in your purchase receipt.
        - paragraph [ref=f2e457]:
          - button "Save changes" [ref=f2e458] [cursor=pointer]
  - contentinfo [ref=f2e459]:
    - paragraph [ref=f2e460]:
      - generic [ref=f2e461]:
        - text: If you like
        - strong [ref=f2e462]: WooCommerce
        - text: please leave us a
        - link "five star" [ref=f2e463] [cursor=pointer]:
          - /url: https://wordpress.org/support/plugin/woocommerce/reviews?rate=5#new-post
          - text: ★★★★★
        - text: rating. A huge thanks in advance!
    - paragraph [ref=f2e464]: Version 11.0.0
```

# Test source

```ts
  1   | const { test, expect } = require('@playwright/test');
  2   | const { loginAndOpenSettings, stepShot, resetStepCounter, saveSettings } = require('./helpers');
  3   | 
  4   | /**
  5   |  * Covers every free-plugin setting field on WooCommerce → Settings → Loyalty
  6   |  * Points: change it, save, reload, confirm the new value persisted. Runs
  7   |  * against the "free-only" QIT environment (PointBayPro not installed).
  8   |  */
  9   | 
  10  | /** Numeric fields: [row label substring, new value to set, expected persisted value]. */
  11  | const NUMBER_FIELDS = [
  12  | 	{ label: 'Points Per Dollar', value: '5' },
  13  | 	{ label: 'Points for Registration', value: '250' },
  14  | 	{ label: 'Points for Product Review', value: '75' },
  15  | 	{ label: 'Point Value ($)', value: '0.05' },
  16  | 	{ label: 'Minimum Points to Redeem', value: '200' },
  17  | 	{ label: 'Referral Bonus Points', value: '1500' },
  18  | ];
  19  | 
  20  | /** Select fields: [row label substring, option value to choose]. */
  21  | const SELECT_FIELDS = [
  22  | 	{ label: 'Order Status Trigger', value: 'processing' },
  23  | 	{ label: 'Redemption Mode', value: 'coupon' },
  24  | ];
  25  | 
  26  | /** Checkbox fields: [row label substring]. */
  27  | const CHECKBOX_FIELDS = ['Enable Referrals', 'Guest Notice', 'Delete Data on Uninstall', 'Debug Logging'];
  28  | 
  29  | test.describe('Free plugin — Settings save/persist (Pro inactive)', () => {
  30  | 	test.beforeEach(async ({ page }, testInfo) => {
  31  | 		resetStepCounter();
  32  | 		await loginAndOpenSettings(page);
  33  | 		await stepShot(page, testInfo, 'settings-loaded');
  34  | 	});
  35  | 
  36  | 	for (const field of NUMBER_FIELDS) {
  37  | 		test(`${field.label} saves and persists`, async ({ page }, testInfo) => {
  38  | 			const row = page.locator('tr', { has: page.locator('th', { hasText: field.label }) });
  39  | 			const input = row.locator('input').first();
  40  | 
  41  | 			// Referral Bonus Points is disabled until Enable Referrals is on.
  42  | 			if (field.label === 'Referral Bonus Points') {
  43  | 				const enableReferralsRow = page.locator('tr', { has: page.locator('th', { hasText: 'Enable Referrals' }) });
  44  | 				const checkbox = enableReferralsRow.locator('input[type="checkbox"]');
  45  | 				if (!(await checkbox.isChecked())) {
  46  | 					await enableReferralsRow.locator('label').first().click();
  47  | 				}
  48  | 			}
  49  | 
  50  | 			await expect(input).toBeVisible();
  51  | 			await stepShot(page, testInfo, `${field.label}-before`);
  52  | 
  53  | 			await input.fill('');
  54  | 			await input.fill(field.value);
  55  | 			await stepShot(page, testInfo, `${field.label}-changed`);
  56  | 
> 57  | 			await saveSettings(page);
      |          ^ TypeError: saveSettings is not a function
  58  | 			await stepShot(page, testInfo, `${field.label}-saved`);
  59  | 
  60  | 			await page.reload();
  61  | 			await page.waitForSelector('.pointbay-p-page-default');
  62  | 			const reloadedRow = page.locator('tr', { has: page.locator('th', { hasText: field.label }) });
  63  | 			const reloadedInput = reloadedRow.locator('input').first();
  64  | 			await expect(reloadedInput).toHaveValue(field.value);
  65  | 			await stepShot(page, testInfo, `${field.label}-reloaded-confirmed`);
  66  | 		});
  67  | 	}
  68  | 
  69  | 	for (const field of SELECT_FIELDS) {
  70  | 		test(`${field.label} saves and persists`, async ({ page }, testInfo) => {
  71  | 			const row = page.locator('tr', { has: page.locator('th', { hasText: field.label }) });
  72  | 			const select = row.locator('select');
  73  | 
  74  | 			await expect(select).toBeVisible();
  75  | 			await stepShot(page, testInfo, `${field.label}-before`);
  76  | 
  77  | 			await select.selectOption(field.value);
  78  | 			await stepShot(page, testInfo, `${field.label}-changed`);
  79  | 
  80  | 			await saveSettings(page);
  81  | 			await stepShot(page, testInfo, `${field.label}-saved`);
  82  | 
  83  | 			await page.reload();
  84  | 			await page.waitForSelector('.pointbay-p-page-default');
  85  | 			const reloadedRow = page.locator('tr', { has: page.locator('th', { hasText: field.label }) });
  86  | 			await expect(reloadedRow.locator('select')).toHaveValue(field.value);
  87  | 			await stepShot(page, testInfo, `${field.label}-reloaded-confirmed`);
  88  | 		});
  89  | 	}
  90  | 
  91  | 	for (const label of CHECKBOX_FIELDS) {
  92  | 		test(`${label} toggle saves and persists`, async ({ page }, testInfo) => {
  93  | 			const row = page.locator('tr', { has: page.locator('th', { hasText: label }) });
  94  | 			const checkbox = row.locator('input[type="checkbox"]');
  95  | 
  96  | 			await stepShot(page, testInfo, `${label}-before`);
  97  | 			const wasChecked = await checkbox.isChecked();
  98  | 
  99  | 			await row.locator('label').first().click();
  100 | 			await stepShot(page, testInfo, `${label}-toggled`);
  101 | 			await expect(checkbox).toHaveJSProperty('checked', !wasChecked);
  102 | 
  103 | 			await saveSettings(page);
  104 | 			await stepShot(page, testInfo, `${label}-saved`);
  105 | 
  106 | 			await page.reload();
  107 | 			await page.waitForSelector('.pointbay-p-page-default');
  108 | 			const reloadedRow = page.locator('tr', { has: page.locator('th', { hasText: label }) });
  109 | 			await expect(reloadedRow.locator('input[type="checkbox"]')).toHaveJSProperty('checked', !wasChecked);
  110 | 			await stepShot(page, testInfo, `${label}-reloaded-confirmed`);
  111 | 
  112 | 			// Restore original state so this test is repeatable and doesn't
  113 | 			// leak a changed toggle into the next test in the file.
  114 | 			await reloadedRow.locator('label').first().click();
  115 | 			await saveSettings(page);
  116 | 		});
  117 | 	}
  118 | });
  119 | 
```